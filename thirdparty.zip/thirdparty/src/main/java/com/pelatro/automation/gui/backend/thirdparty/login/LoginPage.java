package com.pelatro.automation.gui.backend.thirdparty.login;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;


import com.pelatro.automation.gui.backend.thirdparty.generic.Page;

import net.serenitybdd.core.annotations.findby.By;
import net.serenitybdd.core.annotations.findby.FindBy;

public class LoginPage extends Page {
	
	 private static final String LOGOUT_BUTTON_XPATH = "//a[@class='wp-block-button__link has-text-color has-background has-very-dark-gray-background-color' and text()='Log out']";
	    private static final String SUCCESS_TEXT = "Congratulations";
	    
	    @FindBy(id = "error") // Replace with the actual ID of the error message element
	    private WebElement errorMessage;
	
	public LoginPage(WebDriver driver) {
		super(driver);
	}
	
	
public void enterUsernamepwd(String userName, String password) {
		
		String userNameXpath = "//input[@id='username']";
		String passwordXpath="//input[@id='password']";
		String submitXpath= "//button[@id='submit']";
		
		type(userNameXpath,userName);
		type(passwordXpath,password);
		click(submitXpath);	
	}
public void verifyUrlContains(String expectedUrl) {
    String currentUrl = driver.getCurrentUrl();
    if (!currentUrl.contains(expectedUrl)) {
        throw new AssertionError("URL does not contain expected value. Found: " + currentUrl);
    }
}



// Method to verify if the "Log out" button is displayed
public void verifyLogoutButtonIsDisplayed() {
    WebElement logoutButton = driver.findElement(By.xpath(LOGOUT_BUTTON_XPATH));
    if (!logoutButton.isDisplayed()) {
        throw new AssertionError("Log out button is not displayed.");
    }
}
public boolean isErrorMessageDisplayed() {
    return errorMessage.isDisplayed();
}

public String getErrorMessageText() {
    return errorMessage.getText();
}

}
