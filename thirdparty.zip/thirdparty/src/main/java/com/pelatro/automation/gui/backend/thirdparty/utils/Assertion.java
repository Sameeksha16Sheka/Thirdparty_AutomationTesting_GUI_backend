package com.pelatro.automation.gui.backend.thirdparty.utils;

import java.awt.Toolkit;
import java.util.ArrayList;
import java.util.List;
 
import org.hamcrest.Description;
import org.hamcrest.Matcher;
import org.hamcrest.StringDescription;

import cucumber.api.java.en.And;
 
public class Assertion {
	
	public List<String> filedMessages = new ArrayList<String>();;
	private boolean isDebudModeOnForAssertions;
 
	public void assertThat(String reason, boolean assertion) {
		if (!assertion) {
			for (int i = 1 ; i <= 10 ; i++) 
				Toolkit.getDefaultToolkit().beep();
			throw new AssertionError(reason);
		} else if (isDebudModeOnForAssertions)
			System.out.println("\n<<<<< VALIDATION PASSED AGAINST >>>>> " + reason + "\n");
	}
	public <T> void assertThat(T actual, Matcher<? super T> matcher) {
		assertThat("", actual, matcher);
	}
 
	public <T> void assertThat(String reason, T actual, Matcher<? super T> matcher) {
		if (!matcher.matches(actual)) {
			Description description = new StringDescription();
			description.appendText(reason).appendText("\nExpected: ").appendDescriptionOf(matcher)
					.appendText("\n     But: it ");
			matcher.describeMismatch(actual, description);
			throw new AssertionError(description.toString());
		} else if (isDebudModeOnForAssertions)
			System.out.println("\n<<<<< VALIDATION PASSED AGAINST >>>>> " + reason + "\n");
	}
	public <T> void fileIt(String message, T actual, Matcher<? super T> matcher) {
		if (!matcher.matches(actual)) {
			Description description = new StringDescription();
			description.appendText(message).appendText("\nExpected: ").appendDescriptionOf(matcher)
					.appendText("\n     But: it ");
			matcher.describeMismatch(actual, description);
			System.out.println("%%%%%%% Filing the issue >>> " + message);
			filedMessages.add(description.toString());
		} else if (isDebudModeOnForAssertions)
			System.out.println("\n<<<<< VALIDATION PASSED AGAINST >>>>> " + message + "\n");
	}
	public void fileIt(String message) {
		filedMessages.add(message);
	}
	public void fireIt() {
		if (filedMessages.isEmpty())
			return;
		else {
			List<String> issues = new ArrayList<>();
			issues.addAll(filedMessages);
			filedMessages.clear();
			assertThat(String.valueOf(issues), Boolean.FALSE);
		}
	}
	public void clearFiledIssues() {
		filedMessages.clear();
	}
	public void fileIt(String message, boolean assertion) {
		if (!assertion) {
			Description description = new StringDescription();
			description.appendText(message);
			filedMessages.add(description.toString());
		} else if (isDebudModeOnForAssertions)
			System.out.println("\n<<<<< VALIDATION PASSED AGAINST >>>>> " + message + "\n");
	}
	@And("download the temp file")
	public void downloadTempFile() {
	    // Define the path to the temp file on the remote server
	    String remoteTempFilePath = "/home/pelatro/tmp.txt";  // Path to the temp file on the remote server
	    
	    // Define the target machine details (the system where you want to download the file)
	    String targetSystemIP = "192.168.8.96";  // IP address of the target machine (remote system)
	    String targetSystemUsername = "pelatro";  // Username on the target machine
	    String localDestinationPath = "/home/pelatro/Downloads/tmp.txt";  // Local destination path

	    // Construct the SCP command to copy the temp file to the local system
	    String scpCommand = String.format("scp %s@%s:%s %s", targetSystemUsername, targetSystemIP, remoteTempFilePath, localDestinationPath);

	    // Execute the SCP command
	    String result = new ConnectRemoteServer().execute(scpCommand);

	    // Print the result of the download operation (success/failure)
	    if (result.contains("Permission denied") || result.contains("No such file or directory")) {
	        throw new AssertionError("Failed to download the temp file.");
	    } else {
	        System.out.println("Temp file downloaded successfully to: " + localDestinationPath);
	    }
	}
	
}