package com.pelatro.automation.gui.backend.thirdparty.testcase.step;

import org.junit.Assert;
import com.pelatro.automation.gui.backend.thirdparty.login.LoginPage;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class LoginSteps {
	
	private LoginPage loginPage;
	
	@Given("I opened the app using following (.*)")
	public void openApp(String url) {
		loginPage.openAt(url);	
	}
	@When("I enter (.*) and (.*) and press submit")
	public void enterUsernameAndPassword(String userName, String password) {
		loginPage.enterUsernamepwd(userName, password);
	}
	
	@Then("I should see an error message")
    public void verifyErrorMessageIsDisplayed() {
        Assert.assertTrue("Error message is not displayed", loginPage.isErrorMessageDisplayed());
    }
	
	@Then("The new page URL should contain (.*)")
	public void verifyUrlContains(String expectedUrl) {
        loginPage.verifyUrlContains(expectedUrl);
    }
	
	
    @And("The Log out button should be displayed")
    public void verifyLogoutButtonIsDisplayed() {
        loginPage.verifyLogoutButtonIsDisplayed();
    }

}