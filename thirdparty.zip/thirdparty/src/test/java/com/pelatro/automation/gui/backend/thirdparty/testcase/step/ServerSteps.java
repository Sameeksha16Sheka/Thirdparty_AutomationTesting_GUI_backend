package com.pelatro.automation.gui.backend.thirdparty.testcase.step;

import com.pelatro.automation.gui.backend.thirdparty.utils.ConnectRemoteServer;

import cucumber.api.java.en.And;
import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;

public class ServerSteps {
	
	@Given("I created a directory (.*) in my home directory")
	public void createDirectory(String dirName) {
		new ConnectRemoteServer().execute("mkdir -p /home/pelatro/" + dirName);
		String ls = new ConnectRemoteServer().execute("ls /home/pelatro/" + dirName);
		if (ls.contains("No such file or directory"))
			throw new AssertionError("Directory creation is failed !!!");
	}
	
	@Then("create (.*) files in directory (.*)")
    public void createFilesInDirectory(int NoofFiles, String dirName) {
        // Create files based on the NoofFiles
        for (int i = 1; i <= NoofFiles; i++) {
            String fileName = "file" + i + ".txt";
            createFileInDirectory(fileName, dirName);
        }
    }

    private void createFileInDirectory(String fileName, String dirName) {
        // Create the file in the directory
        String createFileCommand = String.format("touch /home/pelatro/%s/%s", dirName, fileName);
        new ConnectRemoteServer().execute(createFileCommand);
        
        // Add content to the file
        addContentToFile(fileName, dirName);
        
        // Verify the file was created successfully
        String ls = new ConnectRemoteServer().execute("ls /home/pelatro/" + dirName);
        if (!ls.contains(fileName)) {
            throw new AssertionError("File creation failed for " + fileName);
        }
    }

    private void addContentToFile(String fileName, String dirName) {
        // Define 5 different lines of content
        String[] contentLines = {
        	"This is line 1 in " + fileName,
            "This is line 2 in " + fileName,
            "This is line 3 in " + fileName,
            "This is line 4 in " + fileName,
            "This is line 5 in " + fileName

        };
        
        // Iterate through each line and append to the file
        for (String line : contentLines) {
            String addContentCommand = String.format("echo '%s' >> /home/pelatro/%s/%s", line, dirName, fileName);
            new ConnectRemoteServer().execute(addContentCommand);
        }
        }
	    
	    @And("list all the files of directory (.*)")
	    public void listFilesInDirectory(String dirName) {
	        // Use the dirName variable dynamically in the command
	        String listFilesCommand = String.format("ls /home/pelatro/%s", dirName);
	        
	        // Execute the command and get the result
	        String lsResult = new ConnectRemoteServer().execute(listFilesCommand);
	        
	        // Print the result to verify the files in the directory
	        System.out.println("Files in directory " + dirName + ": \n" + lsResult);
	    }
	    
	    @And("copy all the files content of (.*) to (.*) file and print content of temp file")
	    public void copyAllContentToTempFile(String dirName, String tempFileName) {
	        // Command to concatenate content of all files in the directory and copy to temp file
	        String copyContentCommand = String.format(
	            "cat /home/pelatro/%s/* > /home/pelatro/%s", dirName, tempFileName);

	        // Execute the command to copy content to temp file
	        new ConnectRemoteServer().execute(copyContentCommand);

	        // Verify the content in the temp file
	        String verifyContentCommand = String.format("cat /home/pelatro/%s", tempFileName);
	        String tempContent = new ConnectRemoteServer().execute(verifyContentCommand);

	        // Print the content of the temp file
	        System.out.println("Content of the temporary file: \n" + tempContent);
	    }
	    @And("download the temp file")
	    public void downloadTempFile() {
	        // Define the path to the temp file on the remote system (same system in this case)
	        String remoteTempFilePath = "/home/pelatro/tmp.txt";  // Path to the temp file on the system
	        
	        // Define the local destination path (same system)
	        String localDestinationPath = "/home/pelatro/Downloads/tmp.txt";  // Local path where the file will be copied

	        // Construct the SCP command to copy the file within the same system (localhost as the target IP)
	        String scpCommand = String.format("scp %s@localhost:%s %s", "pelatro", remoteTempFilePath, localDestinationPath);

	        // Execute the SCP command
	        String result = new ConnectRemoteServer().execute(scpCommand);

	        // Print the result of the download operation (success/failure)
	        if (result.contains("Permission denied") || result.contains("No such file or directory")) {
	            throw new AssertionError("Failed to download the temp file.");
	        } else {
	            System.out.println("Temp file downloaded successfully to: " + localDestinationPath);
	        }
	    }
	    
}